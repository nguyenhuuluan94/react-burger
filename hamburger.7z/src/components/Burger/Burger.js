import React from 'react'

const burger = (props) => {
    return (
        <div></div>
    )
}

export default burger;